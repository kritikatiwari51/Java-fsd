package Calling;

public class methodExecution {

    // Method to add two integers
    public static int add(int a, int b) {
        return a + b;
    }

    // Method to concatenate two strings
    public static String concatenate(String str1, String str2) {
        return str1 + str2;
    }

    public static void main(String[] args) {
        // Verify the add method
        int result1 = add(3, 5);
        System.out.println("Result of add method: " + result1);

        // Verify the concatenate method
        String result2 = concatenate("Hello", " World!");
        System.out.println("Result of concatenate method: " + result2);

        // Another way of calling the add method
        int x = 7, y = 9;
        int result3 = add(x, y);
        System.out.println("Another way of calling add method: " + result3);

        // Another way of calling the concatenate method
        String result4 = concatenate("Java", " Programming");
        System.out.println("Another way of calling concatenate method: " + result4);
    }
}

 











