package camelcasting;
//AccessModifiersExample.java

//A class with different access modifiers
public class camelcasing {
 // Public variable accessible from anywhere
 public int publicVar = 10;

 // Protected variable accessible within the same package and by subclasses
 protected int protectedVar = 20;

 // Default (package-private) variable accessible within the same package
 int defaultVar = 30;

 // Private variable accessible only within the same class
 private int privateVar = 40;

 // Public method accessible from anywhere
 public void publicMethod() {
     System.out.println("Public method");
 }

 // Protected method accessible within the same package and by subclasses
 protected void protectedMethod() {
     System.out.println("Protected method");
 }

 // Default (package-private) method accessible within the same package
 void defaultMethod() {
     System.out.println("Default method");
 }

 // Private method accessible only within the same class
 private void privateMethod() {
     System.out.println("Private method");
 }

 public static void main(String[] args) {
     // Create an instance of the class
     camelcasing example = new camelcasing();

     // Accessing variables
     System.out.println("Public variable: " + example.publicVar);
     System.out.println("Protected variable: " + example.protectedVar);
     System.out.println("Default variable: " + example.defaultVar);
     System.out.println("Private variable: " + example.privateVar); // This will result in a compilation error

     // Accessing methods
     example.publicMethod();
     example.protectedMethod();
     example.defaultMethod();
     example.privateMethod(); // This will result in a compilation error
 }
}


